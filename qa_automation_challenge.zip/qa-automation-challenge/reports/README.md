# Reports Folder

Place your test reports or output files in this folder.

This could include:
- Console logs
- HTML reports
- Screenshots of failed/passed tests

Make sure the reports clearly show which tests passed or failed.
