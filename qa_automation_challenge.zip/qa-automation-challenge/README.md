# QA Automation Challenge – SVR Website

## Objective
Automate key workflows on https://svr.com to demonstrate your ability to:
- Write maintainable automated tests
- Handle dynamic UI elements
- Validate error and success flows
- Produce clear test reports

## Tools & Language
- Candidate's choice: Playwright (preferred), Selenium, Cypress, etc.

## Scenarios
See scenarios.md for full details.

## Instructions
1. Clone this repository.
2. Add your automation scripts under the tests/ folder.
3. Add any test reports/output under the reports/ folder.
4. Create a branch with your name (e.g., john-doe) and push your solution.
5. Update the README with instructions to run your tests.
6. Share your submission before the deadline.

## Duration
- Expected: ~2 hours
