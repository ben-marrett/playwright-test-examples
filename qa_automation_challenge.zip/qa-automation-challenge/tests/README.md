# Tests Folder

Place all your automation scripts in this folder.

Examples of scripts you might include:
- Blog navigation
- Pagination verification
- Negative sign-in tests

Ensure your scripts are organized and readable.
